<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\beli_cash;
use App\Models\mobil;
use App\Models\pembeli;

class CashController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('dashboard.cash.index', [
            'mobils' => mobil::get(),
            'pembelis' => pembeli::get()
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('dashboard.cash.index');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'ktp_pembeli' => 'required',
            'kode_mobil' => 'required',
            'cash_bayar' => 'required',
            'cash_tgl' => 'required'
        ]);
        $last_id = beli_cash::select('kode_cash')->orderBy('created_at','desc')->first();

        $kode_cash = ($last_id==null)?sprintf('C%08d',1)
                        :sprintf('C%08d',substr($last_id->kode_cash,1,8)+1);

        $validated['kode_cash'] = $kode_cash;

        // dd($request);
        $input = beli_cash::create($validated);

        if($input) return redirect('dashboard/cash')->with('success', 'Data Cash berhasil diinput');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function faktur(beli_cash $beli_cash){
        $beli_cash->load(['mobil', 'pembeli']);

        dd($beli_cash);
        $data['beli_cash'] = $beli_cash;
        return view('dashboard/cash/faktur', $data);
    }
}
