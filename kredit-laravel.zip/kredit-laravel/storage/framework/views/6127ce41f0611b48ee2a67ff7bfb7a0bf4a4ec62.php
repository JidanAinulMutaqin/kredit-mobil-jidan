
<div class="social">
    <div class="social__container">
        <div class="social__content">
            <i class='bx bxl-facebook-circle social__icon'></i>
            <div class="social__tooltip social__tooltip-left">Facebook</div>
        </div>

        <div class="social__content">
            <i class='bx bxl-instagram-alt social__icon'></i>
            <span class="social__tooltip social__tooltip-top">Instagram</span>
        </div>

        <div class="social__content">
            <i class='bx bxl-twitter social__icon' ></i>
            <span class="social__tooltip social__tooltip-top">Twitter</span>
        </div>

        <div class="social__content">
            <i class='bx bxl-whatsapp social__icon' ></i>
            <span class="social__tooltip social__tooltip-top">Whatsapp</span>
        </div>

        <div class="social__content">
            <i class='bx bxl-discord social__icon' ></i>
            <span class="social__tooltip social__tooltip-right">Discord</span>
        </div>
    </div>
</div>



<footer class="footer mt-auto py-3">
    <div class="container text-center">
        <span class="text-muted">© 2021 <b>Abadi Showroom.</b></span>
    </div>

</footer>
<?php /**PATH C:\applications\kredit-laravel\resources\views/partials/footer.blade.php ENDPATH**/ ?>