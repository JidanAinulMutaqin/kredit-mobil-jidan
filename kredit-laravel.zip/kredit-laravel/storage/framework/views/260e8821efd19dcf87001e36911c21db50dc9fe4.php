<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-info bg-light shadow-lg fixed-top">
    <div class="container">
      <a class="navbar-brand" href="/"><b>Abadi</b></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <li class="nav-item">
            <a class="nav-link <?php echo e(Request::is('home') ? 'active' : ''); ?>" href="/">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?php echo e(Request::is('product') ? 'active' : ''); ?>" href="/product">Product</a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?php echo e(Request::is('promo') ? 'active' : ''); ?>"  href="/promo">Promo</a>
          </li>
          <li>
            <div class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              More
              </a>
                <ul class="dropdown-menu shadow" aria-labelledby="navbarDropdown">
                  <li><a class="dropdown-item" href="#">Help Center</a></li>
                  <li><a class="dropdown-item" href="#">About</a></li>
                </ul>
            </div>
          </li>
        </ul>

        <ul class="navbar-nav ms-auto">
            <?php if(auth()->guard()->check()): ?>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                    Welcome back, <?php echo e(auth()->user()->name); ?>

                </a>
                <ul class="dropdown-menu shadow"  aria-labelledby="navbarDropdown">
                      <li><a class="dropdown-item" href="/dashboard"><i class="bi bi-layout-text-sidebar-reverse"></i> Dashboard</a></li>
                      <li><hr class="dropdown-divider"></li>
                      <li>
                          <form action="/logout" method="POST">
                            <?php echo csrf_field(); ?>
                              <button type="submit" class="dropdown-item"><i class="bi bi-box-arrow-right"></i> Logout</button>
                          </form>
                      </li>
                </ul>
            </li>
            <?php else: ?>
            <li class="nav-item">
                <a href="/login" class="nav-link <?php echo e(($active === "login") ? 'active' : ''); ?>"><i class="bi bi-box-arrow-in-right"></i> Login</a>
            </li>
            <?php endif; ?>
        </ul>


      </div>
    </div>
  </nav>
  <!-- Navbar -->

  
  <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
    <div class="carousel-indicators">
        <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
        <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
        <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
    </div>
    <div class="carousel-inner">
        <div class="carousel-item active">
            <img src="https://source.unsplash.com/1200x600/?cars" class="d-block w-100" alt="...">
            <div class="carousel-caption d-none d-md-block">
                <h3><b>Abadi Showroom</b></h3>
                <p>Menyediakan beragam kendaraan mulus dari berbagai pelosok dunia.</p>
            </div>
    </div>
        <div class="carousel-item">
            <img src="https://source.unsplash.com/1200x600/?mclaren" class="d-block w-100" alt="...">
            <div class="carousel-caption d-none d-md-block">
                <h3><b>Abadi Showroom</b></h3>
                <p>Menyediakan beragam kendaraan mulus dari berbagai pelosok dunia.</p>
            </div>
    </div>
        <div class="carousel-item">
            <img src="https://source.unsplash.com/1200x600/?porsche" class="d-block w-100" alt="...">
            <div class="carousel-caption d-none d-md-block">
                <h3><b>Abadi Showroom</b></h3>
                <p>Menyediakan beragam kendaraan mulus dari berbagai pelosok dunia.</p>
            </div>
    </div>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
    </button>
</div>

<?php /**PATH C:\applications\kredit-laravel\resources\views/partials/navbarhome.blade.php ENDPATH**/ ?>