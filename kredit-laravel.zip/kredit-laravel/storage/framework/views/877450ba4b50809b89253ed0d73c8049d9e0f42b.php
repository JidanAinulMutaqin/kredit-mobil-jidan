<div class="l-navbar shadow" id="nav-bar">
    <nav class="nav">
        <div>
            <a href="/" class="nav__logo">
                <i class='bx bx-store nav__logo-icon'></i>
                <span class="nav__logo-name">Abadi Showroom</span>
            </a>

            <div class="nav__list">
                <a href="/dashboard" class="nav__link <?php echo e(Request::is('dashboard') ? 'active' : ''); ?>">
                <i class='bx bx-grid-alt nav__icon' ></i>
                    <span class="nav__name">Dashboard</span>
                </a>

                <a href="/dashboard/mobil" class="nav__link <?php echo e(Request::is('dashboard/mobil*') ? 'active' : ''); ?>">
                    <i class='bx bx-car nav__icon' ></i>
                    <span class="nav__name">Mobil</span>
                </a>

                <a href="/dashboard/pembeli" class="nav__link <?php echo e(Request::is('dashboard/pembeli*') ? 'active' : ''); ?>">
                    <i class='bx bx-user nav__icon' ></i>
                    <span class="nav__name">Pembeli</span>
                </a>

                <a href="/dashboard/cash" class="nav__link <?php echo e(Request::is('dashboard/cash*') ? 'active' : ''); ?>">
                    <i class='bx bx-folder nav__icon' ></i>
                    <span class="nav__name">Cash</span>
                </a>

                <a href="#" class="nav__link">
                    <i class='bx bx-bar-chart-alt-2 nav__icon' ></i>
                    <span class="nav__name">Kredit</span>
                </a>
            </div>
        </div>

        <a href="#" class="nav__link">
            <i class='bx bx-log-out nav__icon' ></i>
            <form action="/logout" method="POST">
                <?php echo csrf_field(); ?>
                <button type="submit" class="nav-link px-3 bg-light border-0 rounded">Logout</button>
            </form>
        </a>
    </nav>
</div>
<?php /**PATH C:\applications\kredit-laravel\resources\views/dashboard/layouts/sidebar.blade.php ENDPATH**/ ?>