<?php $__env->startSection('tubuh'); ?>

<div class="card mt-5 mb-6 mx-auto w-50 border-0 shadow" width="300px">
    <div class="card-body">
        <blockquote class="blockquote mb-0">
            <p>Pelanggan adalah keluarga jadi tak usah sungkan.</p>
            <footer class="blockquote-footer">CEO <cite title="Source Title">Abadi Showroom</cite></footer>
        </blockquote>
    </div>
</div>

<div>

</div>

<div class="container col-lg-12 mt-5 p-3 rounded" style="background-color: #ebf6f9;"data-aos="zoom-out-down" data-aos-duration="2000">

    <h3 class=" text-start"><b>Mobil Pilihan</b></h3>
    <div class="row">
        <!-- card1 -->
        <div class="col-md-3">
            <div class="card mt-3 mx-auto border-0 shadow" style="width: 15rem;">
                <img src="https://source.unsplash.com/360x270/?honda" class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title">Honda</h5>
                    <p>Mulai dari Rp 79.000.000</p>
                    <a href="#" class="text-decoration-none">Selengkapnya</a>
                </div>
            </div>
        </div>
        <!-- end card1 -->
        <!-- card2 -->
        <div class="col-md-3">
            <div class="card mt-3 mx-auto border-0 shadow" style="width: 15rem;">
                <img src="https://source.unsplash.com/360x270/?mercedes" class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title">Mercedes Benz</h5>
                    <p>Mulai dari Rp 129.000.000</p>
                    <a href="#" class="text-decoration-none">Selengkapnya</a>
                </div>
            </div>
        </div>
        <!-- end card2 -->
        <!-- card3 -->
        <div class="col-md-3">
            <div class="card mt-3 mx-auto border-0 shadow" style="width: 15rem;">
                <img src="https://source.unsplash.com/360x270/?nissan" class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title">Nissan</h5>
                    <p>Mulai dari Rp 69.000.000</p>
                    <a href="#" class="text-decoration-none">Selengkapnya</a>
                </div>
            </div>
        </div>
         <!-- end card3 -->
        <!-- card4 -->
        <div class="col-md-3">
            <div class="card mt-3 mx-auto border-0 shadow" style="width: 15rem;">
                <img src="https://source.unsplash.com/360x270/?toyota" class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title">Toyota</h5>
                    <p>Mulai dari Rp 89.000.000</p>
                    <a href="#" class="text-decoration-none">Selengkapnya</a>
                </div>
            </div>
        </div>
        <!-- end card4 -->
    </div>
</div>

<div class="container mt-5 mb-5 col-lg-6">
    <div class="row justify-content-center">
        <h3 class="border-bottom text-center mb-3" data-aos="fade-down" data-aos-duration="2000" data-aos-offset="200"><b>Metode Pembayaran</b></h3>
        <div class="col-md-4">
            <a href="#" class="text-decoration-none text-dark">
                <div class="card mx-auto my-auto d-block text-center border-0" data-aos="fade-right" data-aos-duration="2000" data-aos-delay="200">
                    <div class="card-body">
                        <p class="card-text"><i class='bx bx-money'></i> Cash</p>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-md-4">
            <a href="#" class="text-decoration-none text-dark">
                <div class="card mx-auto my-auto d-block text-center border-0" data-aos="fade-left" data-aos-duration="2000" data-aos-delay="200">
                    <div class="card-body">
                        <p class="card-text"><i class='bx bx-coin'></i> Kredit</p>
                    </div>
                </div>
            </a>
        </div>
    </div>
</div>

<div class="container mt-5 mb-5 col-lg-12">
    <div class="row">
        <h3 class="border-bottom text-center mb-3" data-aos="fade-down" data-aos-duration="2000" data-aos-offset="400"><b> Abadi Showroom Offline</b></h3>
        <div class="col-sm-4">
            <div class="card mt-3 mx-auto border-0" style="background-color: #d8ecf3" data-aos="flip-left" data-aos-duration="3000" data-aos-delay="200" data-aos-offset="300">
                <img src="/img/poolpnd.jpg" class="card-img-top rounded" alt="...">
                <div class="card-body rounded">
                    <h5 class="card-title">Bandung</h5>
                    <p>Jl.Sultan Agung No.99</p>
                    <a href="#" class="text-decoration-none">lihat di map</a>
                </div>
            </div>
        </div>
        <div class="col-sm-4">
            <div class="card mt-3 mx-auto border-0" style="background-color: #d8ecf3" data-aos="flip-left" data-aos-duration="3000" data-aos-delay="600" data-aos-offset="300">
                <img src="/img/poolykt.png" class="card-img-top rounded" alt="...">
                <div class="card-body rounded">
                    <h5 class="card-title">Tasikmalaya</h5>
                    <p>Jl.KHZ.Mustofa No.66</p>
                    <a href="#" class="text-decoration-none">lihat di map</a>
                </div>
            </div>
        </div>
        <div class="col-sm-4">
            <div class="card mt-3 mx-auto border-0" style="background-color: #d8ecf3" data-aos="flip-left" data-aos-duration="3000" data-aos-delay="1000" data-aos-offset="300">
                <img src="/img/yogya.jpg" class="card-img-top rounded" alt="...">
                <div class="card-body">
                    <h5 class="card-title">Yogyakarta</h5>
                    <p>Jl.Malioboro No.909</p>
                    <a href="#" class="text-decoration-none">lihat di map</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.second', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\applications\kredit-laravel\resources\views/front/index.blade.php ENDPATH**/ ?>