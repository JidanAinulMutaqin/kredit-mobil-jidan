<header class="header shadow" id="header">
    <div class="header__toggle">
        <i class='bx bx-menu' id="header-toggle"></i>
    </div>

    <div class="header__toggle">
        <a class="nav-link" href="#">Welcome back, {{ auth()->user()->name }}</a>
    </div>
</header>
