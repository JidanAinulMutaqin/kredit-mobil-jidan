<table>
    <tr>
        <td>Nama</td>
        <td>{{ $beli_cash->pembeli>nama_pembeli }}</td>
    </tr>
    <tr>
        <td>Mobil</td>
        <td>{{ $beli_cash->mobil->merek_mobil }}</td>
    </tr>
    <tr>
        <td>Mobil</td>
        <td>{{ $beli_cash->cash_bayar }}</td>
    </tr>
</table>
