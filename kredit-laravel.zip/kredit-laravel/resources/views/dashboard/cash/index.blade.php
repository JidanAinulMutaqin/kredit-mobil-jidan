@extends('dashboard.layouts.main')

@section('container')

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Pembelian Cash</h1>
</div>

@if (session()->has('success'))
<div class="alert alert-success text-center" role="alert">
    {{ session('success') }}
</div>
@endif

<form action="{{ route('cash.store') }}" method="POST" id="f-cash">
@csrf

    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 mb-2">
        <h4>Data Pembeli</h4>
    </div>


        <!-- Button trigger modal -->
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#pilihPelangganModal">
            Pembeli
        </button>

        {{-- Modal --}}

        <div class="modal fade" id="pilihPelangganModal" tabindex="-1" aria-labelledby="pilihPelangganModalLabel" aria-hidden="true">
            <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header text-dark">
                <h5 class="modal-title" id="pilihPelangganModalLabel">Data Pembeli</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="table-responsive col-lg-12">
                        <table id="tbl-pelanggan" class="table table-striped table-lg">
                        <thead>
                            <tr>
                            <th scope="col">No</th>
                            <th scope="col">KTP</th>
                            <th scope="col">Nama</th>
                            <th scope="col">Alamat</th>
                            <th scope="col">Telepon</th>
                            <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($pembelis as $pembeli)
                                <tr>
                                    <td>{{ $loop->iteration }}</td>
                                    <td>{{ $pembeli->ktp_pembeli }}</td>
                                    <td>{{ $pembeli->nama_pembeli }}</td>
                                    <td>{{ $pembeli->alamat_pembeli }}</td>
                                    <td>{{ $pembeli->telp_pembeli }}</td>
                                    <td>
                                        <button class="pilih-pelanggan" type="button">Pilih</button>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                        </table>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-dark btn-outline-primary border-0" data-bs-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
            </div>
        </div>


    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 mb-2">
        <h4>Data Mobil</h4>
    </div>

    <div class="table-responsive col-lg-12">
        <!-- Button trigger modal -->
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#pilihMobilModal">
            Mobil
        </button>

        {{-- Modal --}}
            <div class="modal fade" id="pilihMobilModal" tabindex="-1" aria-labelledby="pilihMobilModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header text-dark">
                    <h5 class="modal-title" id="pilihMobilModalLabel">Data Mobil</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="table-responsive col-lg-12">
                            <table id="tbl-mobil" class="table table-striped table-lg">
                                <thead>
                                <tr>
                                    <th scope="col">No</th>
                                    <th scope="col">Kode Mobil</th>
                                    <th scope="col">Merk</th>
                                    <th scope="col">Tipe</th>
                                    <th scope="col">Warna</th>
                                    <th scope="col">Harga</th>
                                    <th scope="col">Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                    @foreach ($mobils as $mobil)
                                    <tr>
                                        <td>{{ $loop->iteration }}</td>
                                        <td>{{ $mobil->kode_mobil }}</td>
                                        <td>{{ $mobil->merek_mobil }}</td>
                                        <td>{{ $mobil->tipe_mobil }}</td>
                                        <td>{{ $mobil->warna_mobil }}</td>
                                        <td>{{ $mobil->harga_mobil }}</td>
                                        <td>
                                            <button class="pilih-mobil" type="button">Pilih</button>
                                        </td>
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-dark btn-outline-primary border-0" data-bs-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
                </div>
            </div>
    </div>

    <div class="row mb-4">
        {{-- card1 --}}
        <div class="col-md-6">
            <div class="card mt-3 mx-auto border-0 shadow">
                <div class="card-body">
                        <div class="mb-3">
                            <label for="ktp_pembeli" class="form-label">No pembeli</label>
                            <input type="text" class="form-control" id="v-ktp" name="ktp_pembeli" required>
                        </div>
                        <div class="mb-3">
                            <label for="nama_pembeli" class="form-label">Nama</label>
                            <input type="text" class="form-control" id="v-nama" name="nama_pembeli">
                        </div>
                        <div class="mb-3">
                            <label for="telp_pembeli" class="form-label">Telepon</label>
                            <input type="text" class="form-control" id="v-telp" name="telp_pembeli">
                        </div>
                </div>
            </div>
        </div>
        {{-- end card1 --}}

        {{-- card2 --}}
        <div class="col-md-6">
            <div class="card mt-4 mx-auto border-0 shadow">
                <div class="card-body">
                        <div class="mb-3">
                        <label for="kode_mobil" class="form-label">Kode Mobil</label>
                        <input type="text" class="form-control" id="v-kode_mobil" name="kode_mobil" required>
                        </div>
                        <div class="mb-3">
                        <label for="merk_mobil" class="form-label">Merek Mobil</label>
                        <input type="text" class="form-control" id="v-merk" name="merk_mobil">
                        </div>
                        <div class="mb-3">
                            <label for="tipe_mobil" class="form-label">Tipe Mobil</label>
                            <input type="text" class="form-control" id="v-tipe" name="tipe_mobil">
                        </div>
                        <div class="mb-3">
                            <label for="warna_mobil" class="form-label">Warna Mobil</label>
                            <input type="text" class="form-control" id="v-warna" name="warna_mobil">
                        </div>
                        <div class="mb-3">
                            <label for="harga_mobil" class="form-label">Harga Mobil</label>
                            <input type="text" class="form-control" id="v-harga" name="harga_mobil">
                        </div>
                </div>
            </div>
        </div>
        {{-- end card 2 --}}
    </div>

    <div class="row mb-4">
        <div class="col-md-6">
            <div class="card mt-4 mx-auto border-0 shadow">
                <div class="card-body">
                    <h3>Pembayaran</h3>
                        <div class="mb-3">
                        <label for="cash_tgl" class="form-label">Tanggal Pembayaran</label>
                        <input type="date" class="form-control @error('cash_tgl') is-invalid @enderror" id="cash_tgl" name="cash_tgl">
                        @error('cash_tgl')
                            <div class="invalid-feedback">
                                {{ $message }}
                            </div>
                        @enderror
                        </div>
                        <div class="mb-3">
                        <label for="cash_bayar" class="form-label">Total Pembayaran</label>
                        <input type="text" class="form-control @error('cash_bayar') is-invalid @enderror" id="cash_bayar" name="cash_bayar">
                        @error('cash_bayar')
                            <div class="invalid-feedback">
                                {{ $message }}
                            </div>
                        @enderror
                        </div>
                </div>
            </div>
        </div>
    </div>

    <div class="mb-3">
        <button type="submit" class="btn btn-dark btn-outline-primary border-0">Bayar</button>
    </div>
</form>

@push('script')
    <script>
        $(function(){
            $('#tbl-pelanggan').DataTable();
            $('#tbl-mobil').DataTable();

            //event pemilihan pelanggan
            $('#tbl-pelanggan').on('click', '.pilih-pelanggan', function(){
                let ele = $(this).closest('tr');
                let ktp_pembeli = ele.find('td:eq(1)').text();
                let nama_pembeli = ele.find('td:eq(2)').text();
                let alamat = ele.find('td:eq(3)').text();
                let telp_pembeli = ele.find('td:eq(4)').text();
                $('#v-ktp').val(ktp_pembeli)
                $('#v-nama').val(nama_pembeli)
                $('#v-alamat').val(alamat)
                $('#v-telp').val(telp_pembeli)
                $('#pilihPelangganModal').modal('hide')
            });

            //event pemilihan mobil
            $('#tbl-mobil').on('click', '.pilih-mobil', function(){
                let ele = $(this).closest('tr');
                let kode_mobil = ele.find('td:eq(1)').text();
                let merk_mobil = ele.find('td:eq(2)').text();
                let tipe_mobil = ele.find('td:eq(3)').text();
                let warna_mobil = ele.find('td:eq(4)').text();
                let harga_mobil = ele.find('td:eq(5)').text();
                $('#v-kode_mobil').val(kode_mobil)
                $('#v-merk').val(merk_mobil)
                $('#v-tipe').val(tipe_mobil)
                $('#v-warna').val(warna_mobil)
                $('#v-harga').val(harga_mobil)
                $('#pilihMobilModal').modal('hide')
            });
        })

        //default tanggal pembayaran
        Date.prototype.toDateInputValue = (function(){
            var local = new Date(this);
            local.setMinutes(this.getMinutes() - thiis.getTimezoneOffset());
            return local.toJSON().slice(0,10);
        })

        $('#cash_tgl').val(new Date().toDateInputValue());

        //validasi pemilihan pembeli dan mobil
        $('#f-cash').submit(function(e){
            e.prevenDefault();
            if($('#v-ktp').val() == ""){
                alert('data pembeli belum dipilih')
            }else if($('#v-kode-mobil').val() == ""){
                alert('data mobil belum dipilih')
            }else{
                e.currentTarget.submit()
            }
        })
    </script>
@endpush

@endsection
